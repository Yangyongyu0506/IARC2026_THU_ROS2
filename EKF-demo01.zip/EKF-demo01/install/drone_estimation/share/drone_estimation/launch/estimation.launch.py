import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    pkg_name = 'drone_estimation'
    pkg_dir = get_package_share_directory(pkg_name)

    # 1. 处理 Xacro/URDF 文件
    xacro_file = os.path.join(pkg_dir, 'urdf', 'drone.urdf.xacro')
    doc = xacro.process_file(xacro_file)
    robot_desc = doc.toprettyxml(indent='  ')

    # 获取配置文件路径
    ekf_config_file = os.path.join(pkg_dir, 'config', 'ekf.yaml')

    # 2. 启动 Gazebo Server 和 Client
    # 使用 ExecuteProcess 开启 Gazebo
    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_init.so', '-s', 'libgazebo_ros_factory.so'],
        output='screen'
    )

    # 3. 在 Gazebo 中生成无人机模型
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'drone', '-topic', 'robot_description'],
        output='screen'
    )

    # 4. 发布机器人状态 (TF)
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_desc,
            'use_sim_time': True
        }]
    )

    # 5. 启动局部 EKF 节点 (Local Filter - Odom Frame)
    # 作用：仅融合 IMU，提供平滑且连续的位姿
    ekf_local = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node_odom',
        output='screen',
        parameters=[ekf_config_file, {'use_sim_time': True}],
        remappings=[('odometry/filtered', '/odometry/local')]
    )

    # 6. 启动全局 EKF 节点 (Global Filter - Map Frame)
    # 作用：融合 IMU + 10Hz 真值修正，提供绝对位姿，消除累计误差
    ekf_global = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node_map',
        output='screen',
        parameters=[ekf_config_file, {'use_sim_time': True}],
        remappings=[('odometry/filtered', '/odometry/global')]
    )

    # 7. 启动真值频率转换器 (100Hz -> 10Hz)
    # 注意：确保你的脚本文件名是 gt.py 且在 CMakeLists.txt 中已正确安装
    throttler_node = Node(
        package=pkg_name,
        executable='gt.py',
        name='gt_throttler',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    # 8. 启动实时状态分析绘图器
    # 注意：在 state_analyzer.py 脚本中，请确保订阅的是 /odometry/global
   

    # 设置仿真时间环境变量，确保节点同步
    return LaunchDescription([
        SetEnvironmentVariable('RCUTILS_LOGGING_BUFFERED_STREAM', '1'),
        gazebo,
        robot_state_publisher,
        spawn_entity,
        ekf_local,
        ekf_global,
        throttler_node,
    ])
