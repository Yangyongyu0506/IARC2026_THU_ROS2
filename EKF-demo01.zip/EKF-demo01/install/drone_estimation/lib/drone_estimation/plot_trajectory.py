#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import matplotlib.pyplot as plt

class TrajectoryPlotter(Node):
    def __init__(self):
        super().__init__('trajectory_plotter')
        
        # 订阅估计值 (EKF输出)
        self.sub_ekf = self.create_subscription(Odometry, '/odometry/global', self.ekf_callback, 10)
        # 订阅真值 (P3D插件输出)
        self.sub_gt = self.create_subscription(Odometry, '/ground_truth/odom', self.gt_callback, 10)

        self.ekf_x, self.ekf_y = [], []
        self.gt_x, self.gt_y = [], []

        # 设置绘图
        plt.ion()
        self.fig, self.ax = plt.subplots()
        self.line_ekf, = self.ax.plot([], [], 'r-', label='EKF Estimate')
        self.line_gt, = self.ax.plot([], [], 'b--', label='Ground Truth')
        self.ax.legend()
        self.ax.set_xlabel('X (m)')
        self.ax.set_ylabel('Y (m)')
        self.ax.set_title('Real-time Trajectory Comparison')

    def ekf_callback(self, msg):
        self.ekf_x.append(msg.pose.pose.position.x)
        self.ekf_y.append(msg.pose.pose.position.y)

    def gt_callback(self, msg):
        self.gt_x.append(msg.pose.pose.position.x)
        self.gt_y.append(msg.pose.pose.position.y)
        self.update_plot()

    def update_plot(self):
        self.line_ekf.set_data(self.ekf_x, self.ekf_y)
        self.line_gt.set_data(self.gt_x, self.gt_y)
        self.ax.relim()
        self.ax.autoscale_view()
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

def main():
    rclpy.init()
    node = TrajectoryPlotter()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    plt.ioff()
    plt.show()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
