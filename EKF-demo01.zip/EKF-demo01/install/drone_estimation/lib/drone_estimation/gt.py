#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry

class GtThrottler(Node):
    def __init__(self):
        super().__init__('gt_throttler')
        self.sub = self.create_subscription(Odometry, '/ground_truth/odom', self.cb, 10)
        self.pub = self.create_publisher(Odometry, '/odom_gt_10hz', 10)
        self.last_msg = None
        self.create_timer(0.1, self.timer_cb) 

    def cb(self, msg):
        self.last_msg = msg

    def timer_cb(self):
        if self.last_msg:
            msg = self.last_msg
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map' # GPS 是在地图参考系下的
            msg.child_frame_id = 'base_footprint'
            
            # 模拟现实：GPS 具有一定的测量噪声协方差
            # 0.1 代表 10cm 的精度波动
            cov = [0.0] * 36
            cov[0] = 0.1  # X
            cov[7] = 0.1  # Y
            cov[14] = 0.1 # Z
            msg.pose.covariance = cov
            
            self.pub.publish(msg)

def main():
    rclpy.init()
    rclpy.spin(GtThrottler())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
