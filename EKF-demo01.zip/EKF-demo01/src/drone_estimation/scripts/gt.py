#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import numpy as np

class GtThrottler(Node):
    def __init__(self):
        super().__init__('gt_throttler')
        self.sub = self.create_subscription(Odometry, '/ground_truth/odom', self.cb, 10)
        self.pub = self.create_publisher(Odometry, '/odom_gt_10hz', 10)
        self.last_msg = None
        
        # --- 噪声参数设置 ---
        self.gps_std_dev = 0.3  # 标准差设为 0.3米（模拟高精度差分GPS）
        # 如果你想模拟普通手机GPS，可以将标准差设为 2.0
        
        self.create_timer(1, self.timer_cb) 

    def cb(self, msg):
        self.last_msg = msg

    def timer_cb(self):
        if self.last_msg:
            msg = self.last_msg
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map' # GPS 是在地图参考系下的
            msg.child_frame_id = 'base_footprint'
            # --- 核心修改：注入高斯噪声 ---
            # random.gauss(mu, sigma) mu是均值，sigma是标准差
            noise_x = random.gauss(0, self.gps_std_dev)
            noise_y = random.gauss(0, self.gps_std_dev)
            
            msg.pose.pose.position.x += noise_x
            msg.pose.pose.position.y += noise_y
            
            # --- 核心修改：设置合理的协方差 ---
            # 协方差 = 标准差的平方 (Variance = std_dev^2)
            variance = self.gps_std_dev ** 2
            
            cov = [0.0] * 36
            cov[0] = variance  # X 轴方差
            cov[7] = variance  # Y 轴方差
            cov[14] = 0.000001 # Z 轴保持稳定
            msg.pose.covariance = cov
            
            
            self.pub.publish(msg)

def main():
    rclpy.init()
    rclpy.spin(GtThrottler())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
