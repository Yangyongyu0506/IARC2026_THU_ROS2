#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, NavSatFix
import matplotlib.pyplot as plt
import numpy as np
from tf_transformations import euler_from_quaternion

class StateAnalyzer(Node):
    def __init__(self):
        super().__init__('state_analyzer')

        # 数据存储
        self.history = {
            'ekf_x': [], 'ekf_y': [],
            'gt_x': [], 'gt_y': [],
            'error': [], 'time': []
        }

        # 订阅话题
        self.sub_ekf = self.create_subscription(Odometry, '/odometry/local', self.ekf_cb, 10)
        self.sub_gt = self.create_subscription(Odometry, '/ground_truth/odom', self.gt_cb, 10)
        self.sub_imu = self.create_subscription(Imu, '/imu/data', self.imu_cb, 10)
        self.sub_gps = self.create_subscription(NavSatFix, '/gps/fix', self.gps_cb, 10)

        # 变量初始化
        self.current_ekf = None
        self.latest_imu = None
        self.latest_gps = None
        
        # 计时器
        self.log_timer = self.create_timer(1.0, self.log_status)

        # 【针对性修改 1】绘图初始化：显式调用 show
        plt.ion()
        self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, figsize=(12, 5))
        plt.show(block=False) 
        
        self.start_time = self.get_clock().now()

    def imu_cb(self, msg):
        self.latest_imu = msg

    def gps_cb(self, msg):
        self.latest_gps = msg

    def ekf_cb(self, msg):
        # 实时更新当前的 EKF 状态
        self.current_ekf = msg

    def gt_cb(self, msg):
        # 以真值更新为基准频率进行绘图记录
        # 记录真值
        gx = msg.pose.pose.position.x
        gy = msg.pose.pose.position.y
        self.history['gt_x'].append(gx)
        self.history['gt_y'].append(gy)
        
        # 【针对性修改 2】同步记录 EKF 值
        # 如果当前还没有收到过 EKF 数据，则填充当前真值防止数组长度不一致导致绘图失败
        if self.current_ekf:
            ex = self.current_ekf.pose.pose.position.x
            ey = self.current_ekf.pose.pose.position.y
            
            # 只有真的收到数据时才计算误差
            error = np.sqrt((ex - gx)**2 + (ey - gy)**2)
            self.history['ekf_x'].append(ex)
            self.history['ekf_y'].append(ey)
        else:
            # 如果没收到数据，存入一个明显的无效值，或者干脆不存
            self.get_logger().warn("等待 EKF 数据中...", once=True)
            return # 跳过本次绘图，直到 EKF 启动
            
        self.history['ekf_x'].append(ex)
        self.history['ekf_y'].append(ey)
        
        # 计算误差
        error = np.sqrt((ex - gx)**2 + (ey - gy)**2)
        curr_time = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
        self.history['error'].append(error)
        self.history['time'].append(curr_time)
        
        # 更新绘图
        self.update_plot()

    def log_status(self):
        if self.current_ekf and len(self.history['error']) > 0 and self.latest_imu:
            self.get_logger().info(f"Current Pos Error: {self.history['error'][-1]:.4f} m")

    def update_plot(self):
        # 限制绘图点数，防止随着时间推移越来越卡
        max_pts = 400 
        
        # 图1: 同步输出 IMU+GPS(EKF) 和 真值的预测轨迹
        self.ax1.clear()
        # 绘制真值 (蓝色)
        self.ax1.plot(self.history['gt_x'][-max_pts:], self.history['gt_y'][-max_pts:], 
                     'b-', label='Ground Truth', linewidth=1.5)
        # 绘制预测值 (红色虚线)
        self.ax1.plot(self.history['ekf_x'][-max_pts:], self.history['ekf_y'][-max_pts:], 
                     'r--', label='EKF (IMU+GPS)', linewidth=1.2)
        
        self.ax1.set_title("Trajectory: GT vs EKF")
        self.ax1.set_xlabel("X (m)")
        self.ax1.set_ylabel("Y (m)")
        self.ax1.legend(loc='upper right')
        self.ax1.grid(True)

        # 图2: 实时展示预测误差
        self.ax2.clear()
        self.ax2.plot(self.history['time'][-max_pts:], self.history['error'][-max_pts:], 'g-')
        self.ax2.set_title("Real-time Estimation Error")
        self.ax2.set_xlabel("Time (s)")
        self.ax2.set_ylabel("Error (m)")
        self.ax2.grid(True)

        # 【针对性修改 3】使用 draw_idle 提高稳定性
        self.fig.canvas.draw_idle()
        plt.pause(0.001)

    def print_final_analysis(self):
        """【针对性修改 4】新增：程序退出时输出统计分析"""
        if len(self.history['error']) > 0:
            err_arr = np.array(self.history['error'])
            rmse = np.sqrt(np.mean(err_arr**2))
            mae = np.mean(err_arr)
            print("\n" + "="*30)
            print("   误差分析结果报告")
            print("="*30)
            print(f"均方根误差 (RMSE): {rmse:.5f} m")
            print(f"平均绝对误差 (MAE):  {mae:.5f} m")
            print(f"最大误差 (Max):      {np.max(err_arr):.5f} m")
            print("="*30)

def main():
    rclpy.init()
    node = StateAnalyzer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        # 退出时打印结果
        node.print_final_analysis()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()